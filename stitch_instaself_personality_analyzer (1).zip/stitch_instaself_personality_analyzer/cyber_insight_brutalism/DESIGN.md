---
name: Cyber-Insight Brutalism
colors:
  surface: '#131314'
  surface-dim: '#131314'
  surface-bright: '#3a393a'
  surface-container-lowest: '#0e0e0f'
  surface-container-low: '#1c1b1c'
  surface-container: '#201f20'
  surface-container-high: '#2a2a2b'
  surface-container-highest: '#353436'
  on-surface: '#e5e2e3'
  on-surface-variant: '#c6c9ab'
  inverse-surface: '#e5e2e3'
  inverse-on-surface: '#313031'
  outline: '#909378'
  outline-variant: '#454932'
  surface-tint: '#b8d300'
  primary: '#ffffff'
  on-primary: '#2c3400'
  primary-container: '#d2f000'
  on-primary-container: '#5d6b00'
  inverse-primary: '#576500'
  secondary: '#ffb1c4'
  on-secondary: '#65002e'
  secondary-container: '#ff4a8d'
  on-secondary-container: '#590028'
  tertiary: '#ffffff'
  on-tertiary: '#303032'
  tertiary-container: '#e4e2e4'
  on-tertiary-container: '#656466'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d2f000'
  primary-fixed-dim: '#b8d300'
  on-primary-fixed: '#191e00'
  on-primary-fixed-variant: '#414c00'
  secondary-fixed: '#ffd9e1'
  secondary-fixed-dim: '#ffb1c4'
  on-secondary-fixed: '#3f001a'
  on-secondary-fixed-variant: '#8f0044'
  tertiary-fixed: '#e4e2e4'
  tertiary-fixed-dim: '#c8c6c8'
  on-tertiary-fixed: '#1b1b1d'
  on-tertiary-fixed-variant: '#474649'
  background: '#131314'
  on-background: '#e5e2e3'
  surface-variant: '#353436'
  electric-lime: '#DFFF00'
  hot-pink: '#FF007F'
  surface-charcoal: '#161618'
  text-primary: '#FFFFFF'
  text-muted: '#A1A1AA'
  border-subtle: '#27272A'
typography:
  display-xl:
    fontFamily: Space Grotesk
    fontSize: 80px
    fontWeight: '700'
    lineHeight: 80px
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: JetBrains Mono
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1200px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
---

## Brand & Style

The design system is engineered for a provocative and high-impact user experience. It adopts a **Polished Brutalist** aesthetic—stripping away unnecessary ornamentation in favor of raw structural elements, heavy borders, and aggressive typography, while maintaining the sophistication of modern software.

The visual narrative is "Insight through Data Analysis." It evokes a sense of digital forensics and psychological profiling. The interface should feel like a high-end terminal or a confidential dossier: mysterious, slightly voyeuristic, and undeniable in its authority. Visual interest is generated through the tension between deep, midnight voids and searing neon interactive elements.

## Colors

The palette is strictly high-contrast to reinforce the edgy, provocative nature of the product. 

- **The Void (#0A0A0B):** Used for the primary background to create depth and a sense of the "infinite scroll" or "underground" space.
- **Electric Lime & Hot Pink:** These are high-energy disruptors. Electric Lime is the primary driver for "Success," "Active," and "Primary Action" states. Hot Pink is used for "Critical Insights," "Error," or "Emotional Highs."
- **Surface Strategy:** Use `#161618` for cards and containers to create subtle separation from the background. 
- **Readability:** All functional text must be `#FFFFFF`. Metadata and secondary labels use `#A1A1AA` to establish a clear information hierarchy without competing with the primary data points.

## Typography

Typography is the cornerstone of this design system's impact. 

1. **Headers (Space Grotesk):** Use heavy weights (Bold/700) and tight letter spacing for a technical, geometric look. Large display sizes should feel overwhelming and authoritative.
2. **UI & Data (JetBrains Mono):** The monospaced nature of JetBrains Mono reinforces the "personality analyzer" and "data-driven" theme. Use this for all body copy, data tables, and input fields.
3. **Hierarchy:** Titles should be significantly larger than body text to create the "Oversized" look requested. All-caps labels are preferred for categorization and metadata.

## Layout & Spacing

The layout follows a **Fixed Grid** model on desktop to maintain a structured, dossier-like appearance, transitioning to a fluid model on mobile. 

- **Grid:** Use a 12-column grid for desktop. Columns should be separated by 24px gutters to allow the dark background to "breathe" between content blocks.
- **Rhythm:** An 8px base unit governs all padding and margins. 
- **Reflow:** On mobile, margins reduce to 20px, and complex data visualizations should stack vertically, prioritizing the "Insight" (the headline) over the raw data.
- **Alignment:** Elements should feel "locked" into the grid. Avoid centering large blocks of text; left-alignment reinforces the brutalist structure.

## Elevation & Depth

This system avoids traditional shadows in favor of **Tonal Layers** and **Glassmorphism**.

- **Surfaces:** Depth is created by placing `#161618` (Surface) containers over the `#0A0A0B` (Background). 
- **Glassmorphism:** Use a `backdrop-filter: blur(12px)` and a semi-transparent border (`rgba(255,255,255,0.1)`) for overlays and sticky navigation elements. This creates a "frosted lens" effect that feels high-tech.
- **Grain Texture:** Apply a subtle noise/grain SVG filter (opacity 0.03) over the entire UI to reduce the clinical "flatness" of digital colors and add a tactile, film-like quality.
- **Borders:** Instead of shadows, use 1px solid borders (`#27272A`) to define card boundaries.

## Shapes

The shape language is primarily **Sharp**. A "Soft" roundedness level (0.25rem) is used only to prevent the UI from feeling physically painful to look at, but the overall impression should be angular and rigid.

- **Buttons & Inputs:** Use the base 4px (0.25rem) radius.
- **Large Cards:** May use the same 4px radius or 0px for a more aggressive brutalist look.
- **Icons:** Should be stroke-based (2px thickness) with sharp miters, mirroring the angularity of the typography.

## Components

- **Buttons:** 
    - *Primary:* Solid Electric Lime background with black text. No shadow. 
    - *Secondary:* Ghost style with Hot Pink 2px border and Hot Pink text.
- **Chips/Badges:** Small, monospaced text in all-caps. Use Electric Lime for positive traits and Hot Pink for "red flag" traits.
- **Cards:** Use the Surface color with a subtle grain texture and a 1px border. Glassmorphic headers within cards are encouraged for data density.
- **Input Fields:** Sharp corners, 2px bottom-border only (unless focused, then full border in Electric Lime). Monospaced placeholder text.
- **Progress Bars/Data Visuals:** Thick, blocky bars. Avoid rounded caps. Use high-contrast gradients between Electric Lime and Hot Pink to show "personality spectrums."
- **Noise Overlay:** Ensure the noise texture is global and consistent, appearing on all surface containers to maintain the "mysterious" aesthetic.