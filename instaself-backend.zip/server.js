import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import OpenAI from 'openai';

dotenv.config();

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
  baseURL: 'https://openrouter.ai/api/v1'
});

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// ALL 21 PRIORITIES - 7x3 GRID
const allPriorities = [
  { icon: '💰', label: 'Money', desc: 'Wealth, financial goals, hustle' },
  { icon: '💪', label: 'Fitness', desc: 'Health, gym, physique' },
  { icon: '👨‍👩‍👧', label: 'Family', desc: 'Parents, siblings, family content' },
  { icon: '😊', label: 'Happiness', desc: 'Joy, positivity, peace' },
  { icon: '🎭', label: 'Creativity', desc: 'Art, music, creative expression' },
  { icon: '👁️', label: 'Validation', desc: 'Likes, followers, recognition' },
  { icon: '💕', label: 'Romance', desc: 'Dating, relationships, love' },
  { icon: '🏢', label: 'Career', desc: 'Professional advancement, work wins' },
  { icon: '📊', label: 'Entrepreneurship', desc: 'Building, startups, ownership' },
  { icon: '🧠', label: 'Growth', desc: 'Learning, self-improvement, skills' },
  { icon: '🌍', label: 'Adventure', desc: 'Travel, exploration, experiences' },
  { icon: '✨', label: 'Luxury', desc: 'Designer brands, high-end lifestyle' },
  { icon: '🏡', label: 'Stability', desc: 'Home, roots, building foundations' },
  { icon: '🌱', label: 'Simplicity', desc: 'Minimalism, intentional living' },
  { icon: '🧘', label: 'Spirituality', desc: 'Meditation, meaning, purpose' },
  { icon: '⚖️', label: 'Activism', desc: 'Social causes, justice, politics' },
  { icon: '🎮', label: 'Entertainment', desc: 'Memes, fun, escapism' },
  { icon: '📚', label: 'Knowledge', desc: 'Learning, philosophy, intellectualism' },
  { icon: '👥', label: 'Community', desc: 'Friends, belonging, social circles' },
  { icon: '🐕', label: 'Pets', desc: 'Animals, care, companionship' },
  { icon: '🎨', label: 'Aesthetics', desc: 'Fashion, design, visual beauty' }
];

// MOCK INSTAGRAM PROFILES
const mockProfiles = {
  'siddharth': {
    username: 'siddharth',
    profilePicture: 'https://api.dicebear.com/7.x/avataaars/svg?seed=siddharth',
    bio: 'CA Inter prep 📚 | Fitness enthusiast | Tech nerd',
    followerCount: 2543
  },
  'john_doe': {
    username: 'john_doe',
    profilePicture: 'https://api.dicebear.com/7.x/avataaars/svg?seed=johndoe',
    bio: 'Entrepreneur 🚀 | Podcast Host 🎙️ | Always Learning',
    followerCount: 5230
  },
  'fitness_girl': {
    username: 'fitness_girl',
    profilePicture: 'https://api.dicebear.com/7.x/avataaars/svg?seed=fitnessgirl',
    bio: '💪 Gym 5x/week | Nutrition nerd | Coffee addict ☕',
    followerCount: 12430
  }
};

// DETAILED MOCK ANALYSES
const mockAnalyses = {
  'siddharth': {
    archetype: "The Ambitious Wanderer",
    subtitle: "Growth-obsessed CA student caught between ambition and procrastination",
    alignmentScore: 73,
    priorityBreakdown: {
      priority1: { name: "Family", score: 12, insight: "Zero family content in 8 months despite being priority" },
      priority2: { name: "Creativity", score: 82, insight: "Consistently sharing creative ideas and problem-solving" },
      priority3: { name: "Growth", score: 68, insight: "Posting about learning but also about procrastination struggles" }
    },
    feedMetrics: {
      aesthetic: 78,
      engagement: 6.2,
      authenticity: 7.2,
      contentDepth: 5.8
    },
    joke: "You follow 12 productivity gurus but your actual watch time is 80% cat videos and exam stress memes. It's giving 'motivational quote in bio, panic folder in camera roll.'",
    insights: [
      {
        label: "Core Vibe",
        text: "You're in that productive limbo — not quite where you want to be, but clearly trying hard. The gap between your aspirations (CA prep) and reality (procrastination scrolling) is actually your superpower, not a weakness. It shows self-awareness."
      },
      {
        label: "Your Contradiction",
        text: "You selected Family as your top priority but your feed shows zero family content. Meanwhile you're posting constantly about studies and gym. That gap between what matters to you and what you're sharing is worth exploring deeply."
      },
      {
        label: "What Excites You",
        text: "Academic breakthroughs, gym PRs, and memes about exam stress. You engage most with content that makes you feel less alone in the struggle. You're hungry for connection through shared challenges."
      },
      {
        label: "Your Blind Spot",
        text: "You're waiting for permission to be 'successful' before you document your journey. But people connect with the messy middle, not just the wins. Your audience would relate 10x more to your real struggles."
      }
    ],
    suggestions: [
      {
        header: "🎯 Action 1: Bridge the Family Gap This Week",
        text: "Post one genuine moment with family — doesn't need to be perfect or polished. This single post could shift your Family alignment score from 12 to 35+. Your parents would love it."
      },
      {
        header: "🧠 Action 2: Share Your Struggle, Not Just Wins",
        text: "Your feed is all about productivity and fitness wins. Start posting about the actual journey — failed attempts at chapters, confusing topics, late-night doubts. This is what makes people actually follow you."
      },
      {
        header: "💪 Action 3: Document Daily Progress Intentionally",
        text: "Start a simple tracker: 'Day X of CA prep' posts. People love progress visualization. Re-run this analysis in 30 days and watch your growth score climb to 85+."
      }
    ]
  },

  'john_doe': {
    archetype: "The Serial Starter",
    subtitle: "Entrepreneur obsessed with the meta-game of building rather than actual building",
    alignmentScore: 82,
    priorityBreakdown: {
      priority1: { name: "Entrepreneurship", score: 88, insight: "Constantly posting about startups, but mostly talking about them" },
      priority2: { name: "Growth", score: 85, insight: "Very focused on learning and self-improvement content" },
      priority3: { name: "Validation", score: 72, insight: "High engagement seeking clearly visible in post patterns" }
    },
    feedMetrics: {
      aesthetic: 85,
      engagement: 8.4,
      authenticity: 6.5,
      contentDepth: 7.2
    },
    joke: "Your feed is 90% motivational quotes about building and 10% actual product updates. You're the human equivalent of a startup pitch deck — polished, inspiring, but where's the traction?",
    insights: [
      {
        label: "Core Vibe",
        text: "You're genuinely ambitious and love the game of entrepreneurship. You're excellent at inspiring people. But here's the thing: you get addicted to the inspiration part and forget the execution part."
      },
      {
        label: "Your Contradiction",
        text: "You talk constantly about 'building in public' yet your actual product updates are sparse. You're building your personal brand more effectively than your actual product. Both are valuable, but be honest about it."
      },
      {
        label: "What Excites You",
        text: "The meta-game of entrepreneurship excites you most — talking about building, podcasting about building, teaching others about building. Less excited by the actual tedious, unglamorous work."
      },
      {
        label: "Your Blind Spot",
        text: "People follow you for inspiration, not because you've built something remarkable *yet*. That's not a bad thing, but be aware of this gap. Your credibility is built on your story, not your product (yet)."
      }
    ],
    suggestions: [
      {
        header: "🎯 Action 1: Post One Failure This Week",
        text: "Break the pattern of only sharing wins. Post something that failed, a problem you're stuck on, a pivot you made. Your authenticity score will jump from 6.5 to 8.5+."
      },
      {
        header: "🧠 Action 2: Document Your Building Process",
        text: "Not the vision, the actual process. Share code screenshots, show bugs, share boring spreadsheets. This is what separates real builders from motivational talkers."
      },
      {
        header: "💪 Action 3: Post Measurable Results Only",
        text: "Your next 10 posts should have one concrete metric: revenue, users acquired, code commits, anything countable. This resets your credibility from inspiration to traction."
      }
    ]
  },

  'fitness_girl': {
    archetype: "The Discipline Evangelist",
    subtitle: "Fitness is your religion and your feed is the scripture",
    alignmentScore: 91,
    priorityBreakdown: {
      priority1: { name: "Fitness", score: 96, insight: "Your entire feed is centered around fitness — form checks, PRs, meal prep" },
      priority2: { name: "Happiness", score: 88, insight: "Posts consistently show genuine joy in your lifestyle" },
      priority3: { name: "Community", score: 85, insight: "Strong engagement with followers, deeply supportive tone" }
    },
    feedMetrics: {
      aesthetic: 92,
      engagement: 9.2,
      authenticity: 8.8,
      contentDepth: 7.6
    },
    joke: "Your feed is so consistent it's almost suspicious. Every single post screams 'I have my life together.' The only question: do you ever have a bad day, or do you just film gym videos instead?",
    insights: [
      {
        label: "Core Vibe",
        text: "You're genuinely disciplined and you love sharing that discipline. Your content resonates because it's authentic — you actually live this lifestyle, not just talk about it. People feel your energy."
      },
      {
        label: "Your Contradiction",
        text: "You're almost too consistent. There's little vulnerability showing. People would actually relate *more* if you occasionally showed the struggle — the motivation dips, cheat days, injuries, doubts."
      },
      {
        label: "What Excites You",
        text: "Tangible, measurable progress excites you most — PRs, body transformations, consistency streaks. You engage most with content that shows literal before-and-afters and metrics."
      },
      {
        label: "Your Blind Spot",
        text: "Your life is actually more interesting than just fitness. You have dimensions beyond the gym. Your followers would love to see those non-fitness parts — they make you human, not less inspiring."
      }
    ],
    suggestions: [
      {
        header: "🎯 Action 1: Post Your 'Off' Day",
        text: "Break character once. Post about a day you didn't hit your targets, or ate something 'bad.' Your followers will relate 100x more. This paradoxically makes you MORE inspiring, not less."
      },
      {
        header: "🧠 Action 2: Share the Why Behind the What",
        text: "You show your workouts. Now show why you do them. Your journey, your fears, your goals. This converts followers into true advocates who care about you, not just your aesthetics."
      },
      {
        header: "💪 Action 3: Collaborate and Feature Others",
        text: "Tag gym buddies, feature other creators, build community. Your personal brand is strong but isolated. Collaboration could push your engagement score from 9.2 to 9.7+."
      }
    ]
  }
};

// API ENDPOINT: Get all priorities
app.get('/api/priorities', (req, res) => {
  res.json(allPriorities);
});

// API ENDPOINT: Analyze Instagram profile
app.post('/api/analyze', async (req, res) => {
  try {
    const { username, selectedPriorities } = req.body;

    if (!username || username.trim() === '') {
      return res.status(400).json({ error: 'Username is required' });
    }

    if (!selectedPriorities || selectedPriorities.length !== 3) {
      return res.status(400).json({ error: 'Please select exactly 3 priorities' });
    }

    await new Promise(resolve => setTimeout(resolve, 2000));

    const cleanUsername = username.toLowerCase().trim().replace('@', '');

    let profile = mockProfiles[cleanUsername];
    if (!profile) {
      profile = {
        username: cleanUsername,
        profilePicture: `https://api.dicebear.com/7.x/avataaars/svg?seed=${cleanUsername}`,
        bio: 'Content creator | Life explorer',
        followerCount: Math.floor(Math.random() * 10000) + 100
      };
    }

    let analysis = mockAnalyses[cleanUsername];

    if (!analysis) {
      const prompt = `You are INSTASELF, a sharp and witty Instagram personality analyzer.

Analyze the Instagram profile "@${cleanUsername}" based on their 3 self-reported life priorities: ${selectedPriorities[0]}, ${selectedPriorities[1]}, ${selectedPriorities[2]}.

Generate a full personality analysis. Be specific, psychologically sharp, witty, and a little savage-but-loving. Make the person feel seen.

Respond with ONLY valid JSON in this exact format, no markdown, no code fences:
{
  "archetype": "A creative 3-4 word personality title (e.g. The Ambitious Wanderer)",
  "subtitle": "One punchy sentence describing them",
  "alignmentScore": <number 0-100>,
  "priorityBreakdown": {
    "priority1": { "name": "${selectedPriorities[0]}", "score": <0-100>, "insight": "One sharp insight about how this priority likely shows in their life" },
    "priority2": { "name": "${selectedPriorities[1]}", "score": <0-100>, "insight": "One sharp insight" },
    "priority3": { "name": "${selectedPriorities[2]}", "score": <0-100>, "insight": "One sharp insight" }
  },
  "feedMetrics": {
    "aesthetic": <0-100>,
    "engagement": <0.0-10.0>,
    "authenticity": <0-10>,
    "contentDepth": <0-10>
  },
  "joke": "One savage-but-loving roast about their likely content habits. Witty and specific.",
  "insights": [
    { "label": "Core Vibe", "text": "2-3 sentences about their overall energy and what drives them" },
    { "label": "Your Contradiction", "text": "2-3 sentences about the gap between their stated priorities and what they likely actually do" },
    { "label": "What Excites You", "text": "2-3 sentences about what genuinely lights them up" },
    { "label": "Your Blind Spot", "text": "2-3 sentences about what they're missing or not seeing about themselves" }
  ],
  "suggestions": [
    { "header": "🎯 Action 1: <short title>", "text": "Specific, actionable advice tied to their priorities" },
    { "header": "🧠 Action 2: <short title>", "text": "Specific, actionable advice" },
    { "header": "💪 Action 3: <short title>", "text": "Specific, actionable advice" }
  ]
}`;

      const completion = await openai.chat.completions.create({
        model: 'openai/gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.85,
        max_tokens: 1200
      });

      analysis = JSON.parse(completion.choices[0].message.content);
    }

    res.json({
      success: true,
      username: profile.username,
      profilePicture: profile.profilePicture,
      bio: profile.bio,
      followerCount: profile.followerCount,
      selectedPriorities: selectedPriorities,
      ...analysis
    });

  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({
      error: 'Failed to analyze profile. Please try again.',
      details: error.message
    });
  }
});

// HEALTH CHECK
app.get('/health', (req, res) => {
  res.json({ status: 'INSTASELF Backend is running' });
});

app.listen(PORT, () => {
  console.log(`\n✅ INSTASELF BACKEND RUNNING`);
  console.log(`🔗 Port: ${PORT}`);
  console.log(`📊 Endpoints: GET /api/priorities | POST /api/analyze | GET /health\n`);
});
